#include <iostream>
#include "bow.h"

// Aggiunge
void add(BagOfWords & b, const std::string w)
{

}

// Cancella
void del(BagOfWords & b, const std::string w)
{

}

// Restituisce conteggio
int count(const BagOfWords & b, std::string w)
{

}
