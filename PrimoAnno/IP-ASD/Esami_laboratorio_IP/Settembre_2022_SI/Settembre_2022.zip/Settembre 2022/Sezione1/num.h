struct num {
  short int digit;
  num * next;
};

num * int2list(int);

num * sum(num* , num* );
