#include "num.h"

num * int2list(int inum)
{

}

num * sum(num * n1, num * n2)
{
}
