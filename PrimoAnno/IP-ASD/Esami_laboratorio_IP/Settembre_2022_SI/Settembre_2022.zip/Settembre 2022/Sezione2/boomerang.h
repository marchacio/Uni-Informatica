#include <vector>

struct punto {
  float x;
  float y;
};

int  contaBoomerang(std::vector<punto>);

bool equals(float, float);
