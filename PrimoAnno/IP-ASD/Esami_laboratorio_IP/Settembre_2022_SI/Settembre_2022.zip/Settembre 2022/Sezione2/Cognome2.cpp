#include <cmath>
#include "boomerang.h"

int contaBoomerang(std::vector<punto> punti)
{
}

bool equals(float a, float b)
{
  float eps = 1e-5;
  return fabs(a-b) < eps;
}
